from django.db import models

class Patient(models.Model):
    Patient_Name = models.CharField(max_length=100)
    Date_OF_Birth = models.CharField(max_length=100)
    age = models.IntegerField()
    phone = models.IntegerField()
    email = models.EmailField(max_length=100)
    gender = models.CharField(max_length=50)
    address = models.TextField()

    def __str__(self):
        return self.Patient_Name
    
    
